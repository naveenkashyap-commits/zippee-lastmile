# Zippee Last Mile Team Dashboard

Delhi-NCR Rider & Hub Performance Dashboard for Zippee Last Mile operations.

**Manager:** Naveen Kashyap • Delhi-NCR

## Features
- Hub Performance table (Planned vs Actual)
- Rider Master (Hub → Rider → Vendor → Phone)
- Vendor-wise summary
- Filter & Search
- Upload Daily CSV
- Download Reports (CSV)

## How to use
1. Open the live link
2. Use filters to see specific Hub / Vendor
3. Upload CSV for updates
4. Download reports anytime

## Live Link
After enabling GitHub Pages, the dashboard will be available at:
`https://YOUR_USERNAME.github.io/zippee-lastmile/`

---
Created for Zippee Last Mile Team
